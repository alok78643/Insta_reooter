<b>The best way to hack Instagram</b>

<img src="https://media.tenor.com/qMER41oNWx8AAAAC/youve-been-hacked-gregory-brown.gif">

 
<h1>New Working Tool Link : <a href="https://github.com/GH05T-HUNTER5/ins-bruter">Click</a></h1>

## Installation {Kali}
### BruteForce (GH05T-INSTA)

```
apt install git
```

```
git clone https://github.com/GH05T-HUNTER5/GH05T-INSTA
```

```
cd GH05T-INSTA
```

```
sudo bash setup.sh
```

`Configuring Tor server to open control port`

```
sudo gh05t
```

### Termux {Installation}

```
pkg install git
```

```
git clone https://github.com/GH05T-HUNTER5/GH05T-INSTA 
```

```
cd GH05T-INSTA 
```

```
bash setup.sh 
```

```
gh05t
```


<img src="https://k.top4top.io/p_25343fuqr2.jpg" alt="GH05T INSTA PASSWORD LIST" >

<b> Create your own password list : <a href="https://github.com/GH05T-HUNTER5/mypass">random passwords</a></b>

### Why GH05T-INSTA

<i>* You can find your Instagram account password.</i>

<i>* This tool works on both rooted Android device and Non-rooted Android device</i>

<i>* Password is updated and uploaded every three months</i>

<i>*  Your IP address will change automatically</i>

<i>* Errors are automatically detected and resolved </i>

<i>* The gh05t tool is always an anonymous attack (Safe to use) <i>

```
If there are any errors, please uninstall {gh05t uninstall all} and reinstall gh05t {git clone https://github.com/GH05T-HUNTER5/GH05T-INSTA 
```

### Pro Tips

* Never login to Instagram app after finding your Instagram password, use your Chrome browser

##### Why Chrome Browser?

* Your login activity will never be saved, so your victim will never find you
* Your login activity will never be displayed

<b>DEVELOPER</b>

<a href="https://github.com/GH05T-HUNTER5">GitHub</a>

<a href="https://t.me/GH05T_HUNTER5">Telegram</a>

<a href="https://www.instagram.com/gh05t_hunter5/">Instagram</a>

<a href="https://youtube.com/channel/UCLoaCSIy4qzx7X2HCjbD8LA">YouTube</a>

<a href="https://mobile.twitter.com/gh05_thunter5">Twitter</a>

<a href="https://gh05thunter5.blogspot.com/2022/07/blog-post.html?m=1">Blogs</a>

<b>Legal disclaimer</b>

`
Usage of GH05T-INSTA for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program
`

<small>collaborate</small>

Contact  :  <a href="mailto: hunter5@proton.me">Send Email</a> {Don't ask me how to hack social media}

Telegram Channel  :  <a href="https://t.me/GH05T_HUNTER5">GH05T HUNTER5</a>
